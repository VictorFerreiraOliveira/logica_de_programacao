const header = document.querySelector(".header");
const hamburger = document.getElementById("hamburger");
const navMenu = document.getElementById("nav-menu");
const navLinks = document.querySelectorAll(".nav-link");
const themeToggle = document.getElementById("theme-toggle");
const themeIcon = themeToggle.querySelector("i");
const revealElements = document.querySelectorAll(".reveal");
const sections = document.querySelectorAll("section[id]");
const heroSlides = document.querySelectorAll(".hero-slide");
const heroDots = document.querySelectorAll(".hero-dot");
const heroPrev = document.getElementById("hero-prev");
const heroNext = document.getElementById("hero-next");
const testimonialCards = document.querySelectorAll(".testimonial-card");
const dots = document.querySelectorAll(".dot");
const contactForm = document.getElementById("contact-form");
const formSuccess = document.getElementById("form-success");

let currentHeroSlide = 0;
let currentTestimonial = 0;
let heroTimer;
let testimonialTimer;

function setHeaderState() {
    header.classList.toggle("scrolled", window.scrollY > 20);
}

function closeMobileMenu() {
    hamburger.classList.remove("active");
    navMenu.classList.remove("active");
    hamburger.setAttribute("aria-expanded", "false");
}

function toggleMobileMenu() {
    const isOpen = navMenu.classList.toggle("active");
    hamburger.classList.toggle("active", isOpen);
    hamburger.setAttribute("aria-expanded", String(isOpen));
}

function applyTheme(theme) {
    const isDark = theme === "dark";
    document.body.classList.toggle("dark-mode", isDark);
    themeIcon.className = isDark ? "fa-solid fa-sun" : "fa-solid fa-moon";
    localStorage.setItem("pires-tech-theme", theme);
}

function loadSavedTheme() {
    const savedTheme = localStorage.getItem("pires-tech-theme");
    applyTheme(savedTheme || "dark");
}

function showHeroSlide(index) {
    heroSlides.forEach((slide, slideIndex) => {
        slide.classList.toggle("active", slideIndex === index);
    });

    heroDots.forEach((dot, dotIndex) => {
        dot.classList.toggle("active", dotIndex === index);
    });

    currentHeroSlide = index;
}

function nextHeroSlide() {
    showHeroSlide((currentHeroSlide + 1) % heroSlides.length);
}

function previousHeroSlide() {
    showHeroSlide((currentHeroSlide - 1 + heroSlides.length) % heroSlides.length);
}

function startHeroSlider() {
    heroTimer = setInterval(nextHeroSlide, 5200);
}

function restartHeroSlider() {
    clearInterval(heroTimer);
    startHeroSlider();
}

function showTestimonial(index) {
    testimonialCards.forEach((card, cardIndex) => {
        card.classList.toggle("active", cardIndex === index);
    });

    dots.forEach((dot, dotIndex) => {
        dot.classList.toggle("active", dotIndex === index);
    });

    currentTestimonial = index;
}

function nextTestimonial() {
    showTestimonial((currentTestimonial + 1) % testimonialCards.length);
}

function startTestimonials() {
    testimonialTimer = setInterval(nextTestimonial, 4800);
}

function restartTestimonials() {
    clearInterval(testimonialTimer);
    startTestimonials();
}

function setError(input, message) {
    const group = input.closest(".form-group");
    const error = group.querySelector(".error-message");

    group.classList.add("error");
    error.textContent = message;
}

function clearError(input) {
    const group = input.closest(".form-group");
    const error = group.querySelector(".error-message");

    group.classList.remove("error");
    error.textContent = "";
}

function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email);
}

function validateForm() {
    const name = document.getElementById("name");
    const email = document.getElementById("email");
    const message = document.getElementById("message");
    let isValid = true;

    if (name.value.trim().length < 3) {
        setError(name, "Digite seu nome com pelo menos 3 caracteres.");
        isValid = false;
    } else {
        clearError(name);
    }

    if (!isValidEmail(email.value.trim())) {
        setError(email, "Digite um e-mail válido.");
        isValid = false;
    } else {
        clearError(email);
    }

    if (message.value.trim().length < 10) {
        setError(message, "Escreva uma mensagem com pelo menos 10 caracteres.");
        isValid = false;
    } else {
        clearError(message);
    }

    return isValid;
}

function setActiveLink() {
    let currentSection = "";

    sections.forEach((section) => {
        const sectionTop = section.offsetTop - 150;
        const sectionHeight = section.offsetHeight;

        if (window.scrollY >= sectionTop && window.scrollY < sectionTop + sectionHeight) {
            currentSection = section.getAttribute("id");
        }
    });

    navLinks.forEach((link) => {
        link.classList.toggle("active", link.getAttribute("href") === `#${currentSection}`);
    });
}

const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
        if (entry.isIntersecting) {
            entry.target.classList.add("visible");
            revealObserver.unobserve(entry.target);
        }
    });
}, {
    threshold: 0.14
});

revealElements.forEach((element) => revealObserver.observe(element));

window.addEventListener("scroll", () => {
    setHeaderState();
    setActiveLink();
});

hamburger.addEventListener("click", toggleMobileMenu);

navLinks.forEach((link) => {
    link.addEventListener("click", closeMobileMenu);
});

themeToggle.addEventListener("click", () => {
    const nextTheme = document.body.classList.contains("dark-mode") ? "light" : "dark";
    applyTheme(nextTheme);
});

heroNext.addEventListener("click", () => {
    nextHeroSlide();
    restartHeroSlider();
});

heroPrev.addEventListener("click", () => {
    previousHeroSlide();
    restartHeroSlider();
});

heroDots.forEach((dot, index) => {
    dot.addEventListener("click", () => {
        showHeroSlide(index);
        restartHeroSlider();
    });
});

dots.forEach((dot, index) => {
    dot.addEventListener("click", () => {
        showTestimonial(index);
        restartTestimonials();
    });
});

contactForm.addEventListener("submit", (event) => {
    event.preventDefault();
    formSuccess.classList.remove("show");

    if (!validateForm()) {
        return;
    }

    contactForm.reset();
    formSuccess.classList.add("show");

    setTimeout(() => {
        formSuccess.classList.remove("show");
    }, 4500);
});

contactForm.querySelectorAll("input, textarea").forEach((field) => {
    field.addEventListener("input", () => clearError(field));
});

document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
        closeMobileMenu();
    }

    if (event.key === "ArrowRight") {
        nextHeroSlide();
        restartHeroSlider();
    }

    if (event.key === "ArrowLeft") {
        previousHeroSlide();
        restartHeroSlider();
    }
});

loadSavedTheme();
setHeaderState();
setActiveLink();
showHeroSlide(0);
showTestimonial(0);
startHeroSlider();
startTestimonials();
