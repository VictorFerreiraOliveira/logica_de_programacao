/* ================================
   INICIALIZAÇÃO DO AOS
   ================================ */

AOS.init({
    duration: 1000,
    once: true,
    offset: 100,
    easing: 'ease-in-out'
});

/* ================================
   PARTICLES.JS - FUNDO ANIMADO
   ================================ */

particlesJS("particles-js", {
    "particles": {
        "number": {
            "value": 50,
            "density": {
                "enable": true,
                "value_area": 1000
            }
        },
        "color": {
            "value": "#00d4ff"
        },
        "shape": {
            "type": "circle"
        },
        "opacity": {
            "value": 0.3,
            "random": true,
            "anim": {
                "enable": true,
                "speed": 0.5,
                "opacity_min": 0.1,
                "sync": false
            }
        },
        "size": {
            "value": 3,
            "random": true,
            "anim": {
                "enable": true,
                "speed": 1,
                "size_min": 0.5,
                "sync": false
            }
        },
        "line_linked": {
            "enable": true,
            "distance": 200,
            "color": "#00d4ff",
            "opacity": 0.15,
            "width": 1.5
        },
        "move": {
            "enable": true,
            "speed": 1.5,
            "direction": "none",
            "random": true,
            "straight": false,
            "out_mode": "out",
            "bounce": false,
            "attract": {
                "enable": false
            }
        }
    },
    "interactivity": {
        "detect_on": "canvas",
        "events": {
            "onhover": {
                "enable": true,
                "mode": "repulse"
            },
            "onclick": {
                "enable": true,
                "mode": "push"
            },
            "resize": true
        },
        "modes": {
            "repulse": {
                "distance": 100,
                "duration": 0.4
            },
            "push": {
                "particles_nb": 3
            }
        }
    },
    "retina_detect": true
});

/* ================================
   EFEITO DE DIGITAÇÃO
   ================================ */

const typingElement = document.getElementById('typing-text');
const phrases = [
    "Estudante de TI",
    "Desenvolvedor Web",
    "Entusiasta de CyberSecurity",
    "Designer Criativo"
];

let currentPhrase = 0;
let currentChar = 0;
let isDeleting = false;
let typingSpeed = 100;
let deletingSpeed = 50;
let delayBetweenPhrases = 2000;

function type() {
    const phrase = phrases[currentPhrase];
    
    if (isDeleting) {
        typingElement.textContent = phrase.substring(0, currentChar - 1);
        currentChar--;
        typingSpeed = deletingSpeed;
    } else {
        typingElement.textContent = phrase.substring(0, currentChar + 1);
        currentChar++;
        typingSpeed = 100;
    }

    if (!isDeleting && currentChar === phrase.length) {
        isDeleting = true;
        typingSpeed = delayBetweenPhrases;
    } else if (isDeleting && currentChar === 0) {
        isDeleting = false;
        currentPhrase = (currentPhrase + 1) % phrases.length;
        typingSpeed = 500;
    }

    setTimeout(type, typingSpeed);
}

document.addEventListener('DOMContentLoaded', () => {
    setTimeout(type, 500);
});

/* ================================
   NAVBAR SCROLL EFFECT
   ================================ */

const navbar = document.querySelector('.navbar');
let lastScrollTop = 0;

window.addEventListener('scroll', () => {
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
    
    if (scrollTop > 50) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }
    
    lastScrollTop = scrollTop <= 0 ? 0 : scrollTop;
});

/* ================================
   MENU MOBILE
   ================================ */

const menuBtn = document.querySelector('.menu-btn');
const navLinks = document.querySelector('.nav-links');

menuBtn.addEventListener('click', () => {
    navLinks.classList.toggle('active');
});

// Fechar menu ao clicar em um link
document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', () => {
        navLinks.classList.remove('active');
    });
});

/* ================================
   SMOOTH SCROLL PARA ÂNCORAS
   ================================ */

document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        const href = this.getAttribute('href');
        if (href !== '#') {
            e.preventDefault();
            const target = document.querySelector(href);
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        }
    });
});

/* ================================
   FORM SUBMISSION
   ================================ */

const contactForm = document.getElementById('contact-form');

if (contactForm) {
    contactForm.addEventListener('submit', function (e) {
        e.preventDefault();
        
        const name = this.querySelector('input[name="name"]').value;
        const email = this.querySelector('input[name="email"]').value;
        const message = this.querySelector('textarea[name="message"]').value;
        
        // Validação básica
        if (!name || !email || !message) {
            showNotification('Por favor, preencha todos os campos!', 'error');
            return;
        }
        
        // Validação de email
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            showNotification('Por favor, insira um email válido!', 'error');
            return;
        }
        
        showNotification('Mensagem enviada com sucesso! 🎉', 'success');
        this.reset();
    });
}

/* ================================
   NOTIFICAÇÕES
   ================================ */

function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        bottom: 30px;
        right: 30px;
        padding: 16px 24px;
        border-radius: 8px;
        font-weight: 600;
        z-index: 9999;
        animation: slideIn 0.3s ease;
        max-width: 400px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
    `;
    
    if (type === 'success') {
        notification.style.background = 'linear-gradient(135deg, #00d4ff 0%, #8338ec 100%)';
        notification.style.color = '#fff';
    } else if (type === 'error') {
        notification.style.background = 'linear-gradient(135deg, #ff006e 0%, #ff4757 100%)';
        notification.style.color = '#fff';
    } else {
        notification.style.background = 'rgba(26, 31, 58, 0.9)';
        notification.style.color = '#00d4ff';
        notification.style.border = '1px solid rgba(0, 212, 255, 0.3)';
    }
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Adicionar animações de notificação
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

/* ================================
   SCROLL REVEAL EFFECT
   ================================ */

const revealElements = document.querySelectorAll('[data-aos]');

const revealOnScroll = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('revealed');
        }
    });
}, {
    threshold: 0.1
});

revealElements.forEach(element => {
    revealOnScroll.observe(element);
});